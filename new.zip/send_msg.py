import requests, os, sys, codecs
from multiprocessing.dummy import Pool
from requests.packages.urllib3.exceptions import InsecureRequestWarning


requests.packages.urllib3.disable_warnings (InsecureRequestWarning)

def send_msg2(text):
    token = "5325995530:AAFVIdwN6viMpf9y0VclAX-q-vxP_YxRZ9s"
    chat_id = "1634271322"
    url_req = "https://api.telegram.org/bot" + token + "/sendMessage" + "?chat_id=" + chat_id + "&text=" + text 
    results = requests.get(url_req)
