import requests, os, sys, codecs
from multiprocessing.dummy import Pool
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from time import time as timer
import time
from random import sample as rand
from platform import system
from colorama import Fore
from colorama import Style
from pprint import pprint
from colorama import init
from re import findall as reg
init (autoreset=True)

requests.packages.urllib3.disable_warnings (InsecureRequestWarning)


def normale(url):
    try:
        headers = {'User-agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.129 Safari/537.36'}
        get_source = requests.post('https://'+url, headers=headers, verify=False, allow_redirects=False)
       
        print('Testing ..  [ ' +url+' ] === [ NORMALE ]')
        all1=get_source.content  
        if "people-events-sdk" in all1:
            open ('used/people-events-sdk.txt', 'a').write (url+ '\n')
            open ('work/people-events-sdk.txt', 'a').write (all1+ '\n')
        if "api.infobip.com" in all1:
            open ('used/api.infobip.com.txt', 'a').write (url+ '\n')
            open ('work/api.infobip.com.txt', 'a').write (all1+ '\n')   
        if "infobip" in all1:
            open ('used/infobip-nort.txt', 'a').write (url+ '\n')
            open ('work/infobip-nort.txt', 'a').write (all1+ '\n')      

    except:
        pass

