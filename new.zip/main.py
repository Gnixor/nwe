from debug import debug
from env4 import ENV
from norm import normale

import requests, os, sys, codecs
from multiprocessing.dummy import Pool
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from time import time as timer
import time
from random import sample as rand
from platform import system
from colorama import Fore
from colorama import Style
from pprint import pprint
from colorama import init
from re import findall as reg
init (autoreset=True)

requests.packages.urllib3.disable_warnings (InsecureRequestWarning)

####### Colors	 ######

fr = Fore.RED
fc = Fore.CYAN
fw = Fore.WHITE
fg = Fore.GREEN
sd = Style.DIM
sn = Style.NORMAL
sb = Style.BRIGHT

#######################
try:
    with codecs.open (sys.argv[1], mode='r', encoding='ascii', errors='ignore') as f:
        ooo = f.read ().splitlines ()
except IOError:
    pass
ooo = list ((ooo))



def banners():
    if system () == 'Linux':
        os.system ('clear')
    if system () == 'Windows':
        os.system ('cls')

        banner = """{}{} \n \n
        
        
        
        

..######...##....##.####.##.....##..#######..########.
.##....##..###...##..##...##...##..##.....##.##.....##
.##........####..##..##....##.##...##.....##.##.....##
.##...####.##.##.##..##.....###....##.....##.########.
.##....##..##..####..##....##.##...##.....##.##...##..
.##....##..##...###..##...##...##..##.....##.##....##.
..######...##....##.####.##.....##..#######..##.....##






		\n""".format (fc, sb)

        print (banner)




def ExploitS(url):
    try:
        debug(url)
        ENV(url)
        
        normale(url)


    
    
    
    
    except:
        print('Failed [ ' +url+' ] ')
        pass        

banners ()

def Main():
    try:

        start = timer ()
        ThreadPool = Pool (500)
        Threads = ThreadPool.map (ExploitS, ooo)
        print('Time: ' + str (timer () - start) + ' seconds')
    except:
        pass


if __name__ == '__main__':
    Main ()
